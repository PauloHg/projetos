-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tempo de Geração: Ago 27, 2016 as 03:48 AM
-- Versão do Servidor: 5.1.54
-- Versão do PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `crud`
--
CREATE DATABASE crud;
USE crud;
-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE IF NOT EXISTS `produtos` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `NOME` varchar(60) NOT NULL,
  `descricao` varchar(60) NOT NULL,
  `PRECO` decimal(5,2) NOT NULL,
  `IMAGEM` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`ID`, `NOME`, `descricao`, `PRECO`, `IMAGEM`) VALUES
(1, 'Mascara alienigena', 'mascara ', 100.00, 'alien.jpg'),
(2, 'Aparador de Grama', 'aparador', 90.00, 'aparador.jpg'),
(3, 'Ketchup maneiro', 'ketchup vermelho', 5.00, 'ketchup.jpg'),
(4, 'Planta', 'planta não venenosa', 250.00, 'planta.jpg'),
(5, 'Violino vermelho', 'violino maneiro', 50.00, 'violino.jpg');
