












<?php
      session_start();
       
	   
	  //SE NÃO TIVER CRIADO A VARIÁVEL CARRINHO, ELA SERÁ CRIADA.
	  //É UM ARRAY
      if(!isset($_SESSION['carrinho'])){
         $_SESSION['carrinho'] = array();
      }
       
      //ADICIONA PRODUTO DENTRO DO ARRAY
       
      if(isset($_GET['acao'])){
          
         //ADICIONAR CARRINHO
         if($_GET['acao'] == 'add'){ //SE A PESSOA CLICOU EM COMPRAR
            $id = intval($_GET['id']); //A VARIÁVEL É CONVERTIDA PARA INTEIRO (O ID DO PRODUTO)
            if(!isset($_SESSION['carrinho'][$id])){
               $_SESSION['carrinho'][$id] = 1; //ADICIONA A QUANTIDADE DO PRODUTO INICIAL AO COMPRAR
            }else{
               $_SESSION['carrinho'][$id] += 1; //SE A PESSOA VAI CLICANDO EM COMPRAR, VAI ADICIONANDO MAIS UM PRODUTO
            }
         }
          
         //REMOVER CARRINHO
         if($_GET['acao'] == 'del'){ //NA URL APARECE ACAO- DEL
            $id = intval($_GET['id']); //CONVERTE O ID PARA INTEIRO
            if(isset($_SESSION['carrinho'][$id])){ //SE TIVER O ID DENTRO DO CARRINHO MESMO
               unset($_SESSION['carrinho'][$id]); //RETIRA O PRODUTO DO CARRINHO
            }
         }
          
         //ALTERAR QUANTIDADE
         if($_GET['acao'] == 'up'){ //NA URL APARECE ACAO-UP
            if(is_array($_POST['prod'])){ 
               foreach($_POST['prod'] as $id => $qtd){
                  $id  = intval($id); //CONVERTE O ID PARA INTEIRO
                  $qtd = intval($qtd); //CONVERTE QUANTIDADE PARA INTEIRO
                  if(!empty($qtd) || $qtd <> 0){ //SE A QUANTIDADE NÃO ESTÁ VAZIA OU É DIFERENTE DE 0
                     $_SESSION['carrinho'][$id] = $qtd; //SESSÃO DO CARRINHO RECEBE A QTDE DEFINIDA PELO USUARIO
                  }else{
                     unset($_SESSION['carrinho'][$id]); //OU A VARIÁVEL ID É DESTRUÍDA
                  }
               }
            }
         }
       
      }
       
       
?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <meta charset="utf-8">
</head>



<style>
 

body {
    color: gray;
    background-image: url("empresa.jpg");
    background-repeat: no-repeat;
    
    background-position: right top;
    background-attachment: fixed;
}






  .box {
    background-color: #B7142F;
    width: 900;
    padding: 25px;
    border: 25px solid navy ;

    border-color: lightgray;
    margin: 25
}

.form {
    color: white;
    font-family: "Verdana", Times, Sans-serif;
}


th {
    width: 100%;
    padding: 15px 32px;
    margin: 4px 2px;
    box-sizing: border-box;
    border: none;
    background-color: white;
    color: black;
    border-radius: 12px;
    font-family: "Lucida Console", Times, monospace;
}

td {
    width: 100%;
    padding: 15px 32px;
    margin: 4px 2px;
    box-sizing: border-box;
    border: none;
    background-color: white;
    color: black;
    border-radius: 12px;
    font-family: "Times New Roman", Times, serif;
}




</style>






 
<body>

<div id="" class="box">
  <div class="form">
<table>
    <h1>Carrinho de Compras</h1>
    <thead>
          <tr>
            <th width="244">Produto</th>
            <th width="79">Quantidade</th>
            <th width="89">Pre&ccedil;o</th>
            <th width="100">SubTotal</th>
            <th width="64">Remover</th>
          </tr>
    </thead>
	
			<!------ESSA PARTE SERVE PARA ATUALIZAÇÃO DO CARRINHO. UTILIZAMOS
				A MESMA PÁGINA QUE ESTÁ ABERTA, FUNCIONA COMO SE FOSSE UM REFRESH.
				LÁ EM CIMA NÓS CRIAMOS O UP-->
            <form action="?acao=up" method="post">
    <tfoot>
           <tr>
            <td colspan="5"><input type="submit" value="Atualizar Carrinho" /></td>
            <tr>
            <td colspan="5"><a href="index.php">Continuar Comprando</a></td>
    </tfoot>
      
    <tbody>
               <?php
                     if(count($_SESSION['carrinho']) == 0){
                        echo '<tr><td colspan="5">Não há produto no carrinho</td></tr>';
                     }else{
                        require("conexao.php");
                                                               $total = 0;
                        foreach($_SESSION['carrinho'] as $id => $qtd){
                              $sql   = "SELECT *  FROM produtos WHERE ID= '$id'";
                              $qr    = mysqli_query($conn, $sql) or die(mysql_error());
                              $ln    = mysqli_fetch_assoc($qr);
                               
                              $nome  = $ln['NOME'];
                              $preco = number_format($ln['PRECO'], 2, ',', '.');
                              $sub   = number_format($ln['PRECO'] * $qtd, 2, ',', '.');
                               
                              $total += $ln['PRECO'] * $qtd;
                            
                           echo '<tr>       
                                 <td>'.$nome.'</td>
                                 <td><input type="text" size="3" name="prod['.$id.']" value="'.$qtd.'" /></td>
                                 <td>R$ '.$preco.'</td>
                                 <td>R$ '.$sub.'</td>
                                 <td><a href="?acao=del&id='.$id.'">Remove</a></td>
                              </tr>';
                        }
                           $total = number_format($total, 2, ',', '.');
						   $_SESSION['valortotal'] = $total;
                           echo '<tr>
                                    <td colspan="4">Total</td>
                                    <td>R$ '.$total.'</td>
									<td><a href="cadastrar.php">Pagar agora</a>
                              </tr>';
                     }
               ?>
     </tbody>
        </form>
</table>
                  </div>

                  </div>
</body>
</html>