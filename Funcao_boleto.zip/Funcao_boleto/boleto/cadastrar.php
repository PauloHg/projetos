<meta charset="utf-8">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">

<body>
<style>	

input[type=text] {
    width: 100%;
    padding: 15px 32px;
    margin: 4px 2px;
    box-sizing: border-box;
    border: none;
    background-color: white;
    color: black;
    border-radius: 12px;
    font-family: "Lucida Console", Times, monospace;
}



body {
    color: gray;
    background-image: url("empresa.jpg");
    background-repeat: no-repeat;
    
    background-position: right top;
    background-attachment: fixed;
}





/* borda do questionario */ 
.box {
    background-color: #B7142F;
    width: 300px;
    padding: 25px;
    border: 25px solid navy ;

    border-color: lightgray;
    margin: 25px;
}


.button {
    background-color: #222222; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 12px;
    width: 100%;
    transition: all 0.5s;
    
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}


.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}


form {
    color: white;
    font-family: "Verdana", Times, Sans-serif;
}



.botao2 {
     background-color: #222222; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 12px;
    width: 10%;
    height:10%; 
    transition: all 0.5s;

}



</style>



<div id="form" class="box">
	<form>
	<center><h2>Cadastrar Cliente</h2></center></form>
	<form method="POST" action="boleto_bb.php">
			<!--<label>Código:</label>
			<input type="text" name="codigo">-->

		    <label>Nome de Usuario:</label>
			<input type="text" name="nome">

			<label>Cidade:</label>
			<input type="text" name="cidade">

			<label>Estado:</label>
			<input type="text" name="estado">

			<label>Endereço:</label>
			<input type="text" name="endereco">

			<label>CEP:</label>
			<input type="text" name="cep">
         
		<button class="button" onClick="return confirm('Deseja cadastrar o cliente?');" name="cadastrar" value="cadastrar" style="vertical-align:middle" type="submit">
    <span>Cadastrar</span></button>
	</form>
</div>




<center><button onclick="location.href='carrinho.php'" class="botao2" type="submit"  value="voltar" style="vertical-align:middle">
<span class="fa fa-arrow-circle-left">Voltar</span></button> 
</center>
</body>