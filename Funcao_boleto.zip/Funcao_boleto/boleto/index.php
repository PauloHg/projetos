<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"> 
	
	<style>

body {
    color: gray;
    background-image: url("empresa.jpg");
    background-repeat: no-repeat;
    
    background-position: right top;
    background-attachment: fixed;
}


.box {
    background-color: #B0C4DE;
    width: 900px;
    padding: 25px;
    border: 25px solid navy ;

    border-color: lightgray;
    margin: 25px;
}


.form {
    color: white;
    font-family: "Verdana", Times, Sans-serif;
}



ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
     position: fixed;
    top: 0;
    width: 100%;
    border: 1px solid #e7e7e7;
    background-color: #B0C4DE;
}

ul.topnav {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

ul.topnav li {float: left;}

ul.topnav li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

ul.topnav li a:hover:not(.active) {background-color: #111;}

ul.topnav li a.active {background-color: lightgray;}

ul.topnav li.right {float: right;}

@media screen and (max-width: 600px){
    ul.topnav li.right,
    ul.topnav li {float: none;}
}




/* botão */

.button {
    background-color: #555555;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;

}





</style>


</head>
<body>

<?php 
require("conexao.php");
$db=mysqli_select_db($conn, "produtos");
$sql=mysqli_query($conn, "SELECT * FROM PRODUTOS") or die (mysqli_error($conn));

  // NAV
    echo '<ul class="topnav">';
    echo '<li><a class="active" href="index.php">Compre Aqui</a></li>';
    
    echo '</ul>' ;


while ($ln=mysqli_fetch_assoc($sql)) {
	
  // PRODUTOS
    echo '<div class="box">';
    echo '<div class="form">';
	echo '<h2>' .$ln['NOME'].'</h2><br>';
	echo 'Preço: R$ '.number_format($ln['PRECO'],2,',','.').'<br>';
    echo '<img src="imagens/'.$ln['IMAGEM'].'"<br>';
    echo '<a class="button" href="carrinho.php?acao=add&id='.$ln['ID'].'">Comprar</a>';
    echo '<br><hr/>';
    echo '</div>';
    echo '</div>';
 	# code...
 } 
?>
</div>


 </div>
</body>
</html>