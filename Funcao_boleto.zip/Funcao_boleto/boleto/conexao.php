<?php 

	$server = "localhost:3306";
	$user = "root";
	$pass = "";
	$db_name = "crud";

	$conn = new mysqli($server, $user, $pass, $db_name);

	$db = mysqli_select_db($conn, "produtos");

?>