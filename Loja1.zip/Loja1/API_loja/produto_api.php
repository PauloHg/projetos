<?php

$arquivo = "http://127.0.0.1/loja/api/produtos";
$info = file_get_contents($arquivo);
$lendo = json_decode($info);

foreach($lendo->rows as $campo){
	echo "<hr>";
	echo "<br /><b> Codigo :</b> ".$campo->codproduto;
	echo "<br /><b>Nome :</b> ".$campo->nomeproduto;
	echo "<br /><b>Tipo :</b> ".$campo->tipoproduto ;
	echo "<br /><b>Quantidade :</b> ".$campo->qtdeproduto;
	echo "<br /><b>Valor :</b> ".$campo->valordeproduto . "<p>" ;
	echo "</hr>";


}

?>