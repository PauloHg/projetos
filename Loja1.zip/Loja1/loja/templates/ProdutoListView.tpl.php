<?php
	$this->assign('title','Loja Maneira | Produtos');
	$this->assign('nav','produtos');

	$this->display('_Header.tpl.php');
?>

<script type="text/javascript">
	$LAB.script("scripts/app/produtos.js").wait(function(){
		$(document).ready(function(){
			page.init();
		});
		
		// hack for IE9 which may respond inconsistently with document.ready
		setTimeout(function(){
			if (!page.isInitialized) page.init();
		},1000);
	});
</script>

<div class="container">

<h1>
	<i class="icon-th-list"></i> Produtos
	<span id=loader class="loader progress progress-striped active"><span class="bar"></span></span>
	<span class='input-append pull-right searchContainer'>
		<input id='filter' type="text" placeholder="Search..." />
		<button class='btn add-on'><i class="icon-search"></i></button>
	</span>
</h1>

	<!-- underscore template for the collection -->
	<script type="text/template" id="produtoCollectionTemplate">
		<table class="collection table table-bordered table-hover">
		<thead>
			<tr>
				<th id="header_Codproduto">Codproduto<% if (page.orderBy == 'Codproduto') { %> <i class='icon-arrow-<%= page.orderDesc ? 'up' : 'down' %>' /><% } %></th>
				<th id="header_Nomeproduto">Nomeproduto<% if (page.orderBy == 'Nomeproduto') { %> <i class='icon-arrow-<%= page.orderDesc ? 'up' : 'down' %>' /><% } %></th>
				<th id="header_Tipoproduto">Tipoproduto<% if (page.orderBy == 'Tipoproduto') { %> <i class='icon-arrow-<%= page.orderDesc ? 'up' : 'down' %>' /><% } %></th>
				<th id="header_Qtdeproduto">Qtdeproduto<% if (page.orderBy == 'Qtdeproduto') { %> <i class='icon-arrow-<%= page.orderDesc ? 'up' : 'down' %>' /><% } %></th>
				<th id="header_Valordeproduto">Valordeproduto<% if (page.orderBy == 'Valordeproduto') { %> <i class='icon-arrow-<%= page.orderDesc ? 'up' : 'down' %>' /><% } %></th>
			</tr>
		</thead>
		<tbody>
		<% items.each(function(item) { %>
			<tr id="<%= _.escape(item.get('codproduto')) %>">
				<td><%= _.escape(item.get('codproduto') || '') %></td>
				<td><%= _.escape(item.get('nomeproduto') || '') %></td>
				<td><%= _.escape(item.get('tipoproduto') || '') %></td>
				<td><%= _.escape(item.get('qtdeproduto') || '') %></td>
				<td><%= _.escape(item.get('valordeproduto') || '') %></td>
			</tr>
		<% }); %>
		</tbody>
		</table>

		<%=  view.getPaginationHtml(page) %>
	</script>

	<!-- underscore template for the model -->
	<script type="text/template" id="produtoModelTemplate">
		<form class="form-horizontal" onsubmit="return false;">
			<fieldset>
				<div id="codprodutoInputContainer" class="control-group">
					<label class="control-label" for="codproduto">Codproduto</label>
					<div class="controls inline-inputs">
						<span class="input-xlarge uneditable-input" id="codproduto"><%= _.escape(item.get('codproduto') || '') %></span>
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="nomeprodutoInputContainer" class="control-group">
					<label class="control-label" for="nomeproduto">Nomeproduto</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="nomeproduto" placeholder="Nomeproduto" value="<%= _.escape(item.get('nomeproduto') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="tipoprodutoInputContainer" class="control-group">
					<label class="control-label" for="tipoproduto">Tipoproduto</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="tipoproduto" placeholder="Tipoproduto" value="<%= _.escape(item.get('tipoproduto') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="qtdeprodutoInputContainer" class="control-group">
					<label class="control-label" for="qtdeproduto">Qtdeproduto</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="qtdeproduto" placeholder="Qtdeproduto" value="<%= _.escape(item.get('qtdeproduto') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
				<div id="valordeprodutoInputContainer" class="control-group">
					<label class="control-label" for="valordeproduto">Valordeproduto</label>
					<div class="controls inline-inputs">
						<input type="text" class="input-xlarge" id="valordeproduto" placeholder="Valordeproduto" value="<%= _.escape(item.get('valordeproduto') || '') %>">
						<span class="help-inline"></span>
					</div>
				</div>
			</fieldset>
		</form>

		<!-- delete button is is a separate form to prevent enter key from triggering a delete -->
		<form id="deleteProdutoButtonContainer" class="form-horizontal" onsubmit="return false;">
			<fieldset>
				<div class="control-group">
					<label class="control-label"></label>
					<div class="controls">
						<button id="deleteProdutoButton" class="btn btn-mini btn-danger"><i class="icon-trash icon-white"></i> Delete Produto</button>
						<span id="confirmDeleteProdutoContainer" class="hide">
							<button id="cancelDeleteProdutoButton" class="btn btn-mini">Cancel</button>
							<button id="confirmDeleteProdutoButton" class="btn btn-mini btn-danger">Confirm</button>
						</span>
					</div>
				</div>
			</fieldset>
		</form>
	</script>

	<!-- modal edit dialog -->
	<div class="modal hide fade" id="produtoDetailDialog">
		<div class="modal-header">
			<a class="close" data-dismiss="modal">&times;</a>
			<h3>
				<i class="icon-edit"></i> Edit Produto
				<span id="modelLoader" class="loader progress progress-striped active"><span class="bar"></span></span>
			</h3>
		</div>
		<div class="modal-body">
			<div id="modelAlert"></div>
			<div id="produtoModelContainer"></div>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" >Cancel</button>
			<button id="saveProdutoButton" class="btn btn-primary">Save Changes</button>
		</div>
	</div>

	<div id="collectionAlert"></div>
	
	<div id="produtoCollectionContainer" class="collectionContainer">
	</div>

	<p id="newButtonContainer" class="buttonContainer">
		<button id="newProdutoButton" class="btn btn-primary">Add Produto</button>
	</p>

</div> <!-- /container -->

<?php
	$this->display('_Footer.tpl.php');
?>
