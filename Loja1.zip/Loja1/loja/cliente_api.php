<?php

$arquivo = "http://127.0.0.1/loja/api/clientes";
$info = file_get_contents($arquivo);
$lendo = json_decode($info);

foreach($lendo->rows as $campo){
	echo "<br /><b> Nome :</b> ".$campo->nomecliente;
	echo "<br /><b>Endereco :</b> ".$campo->enderecocliente;
	echo "<br /><b>Bairro :</b> ".$campo->bairrocliente;
	echo "<br /><b>Estado :</b> ".$campo->estadocliente;
	echo "<br /><b>Telefone :</b> ".$campo->telefonecliente;
	echo "<br /><b>Estado :</b> ".$campo->celularcliente . "<p>";


}

?>