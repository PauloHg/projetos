<?php
/** @package    PhreezeLoja::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * FormaspagamentoCriteria allows custom querying for the Formaspagamento object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package PhreezeLoja::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class FormaspagamentoCriteriaDAO extends Criteria
{

	public $Codigopagamento_Equals;
	public $Codigopagamento_NotEquals;
	public $Codigopagamento_IsLike;
	public $Codigopagamento_IsNotLike;
	public $Codigopagamento_BeginsWith;
	public $Codigopagamento_EndsWith;
	public $Codigopagamento_GreaterThan;
	public $Codigopagamento_GreaterThanOrEqual;
	public $Codigopagamento_LessThan;
	public $Codigopagamento_LessThanOrEqual;
	public $Codigopagamento_In;
	public $Codigopagamento_IsNotEmpty;
	public $Codigopagamento_IsEmpty;
	public $Codigopagamento_BitwiseOr;
	public $Codigopagamento_BitwiseAnd;
	public $Tipopagamento_Equals;
	public $Tipopagamento_NotEquals;
	public $Tipopagamento_IsLike;
	public $Tipopagamento_IsNotLike;
	public $Tipopagamento_BeginsWith;
	public $Tipopagamento_EndsWith;
	public $Tipopagamento_GreaterThan;
	public $Tipopagamento_GreaterThanOrEqual;
	public $Tipopagamento_LessThan;
	public $Tipopagamento_LessThanOrEqual;
	public $Tipopagamento_In;
	public $Tipopagamento_IsNotEmpty;
	public $Tipopagamento_IsEmpty;
	public $Tipopagamento_BitwiseOr;
	public $Tipopagamento_BitwiseAnd;

}

?>