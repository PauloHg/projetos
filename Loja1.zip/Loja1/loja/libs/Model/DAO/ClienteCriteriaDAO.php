<?php
/** @package    PhreezeLoja::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * ClienteCriteria allows custom querying for the Cliente object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package PhreezeLoja::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ClienteCriteriaDAO extends Criteria
{

	public $Nomecliente_Equals;
	public $Nomecliente_NotEquals;
	public $Nomecliente_IsLike;
	public $Nomecliente_IsNotLike;
	public $Nomecliente_BeginsWith;
	public $Nomecliente_EndsWith;
	public $Nomecliente_GreaterThan;
	public $Nomecliente_GreaterThanOrEqual;
	public $Nomecliente_LessThan;
	public $Nomecliente_LessThanOrEqual;
	public $Nomecliente_In;
	public $Nomecliente_IsNotEmpty;
	public $Nomecliente_IsEmpty;
	public $Nomecliente_BitwiseOr;
	public $Nomecliente_BitwiseAnd;
	public $Enderecocliente_Equals;
	public $Enderecocliente_NotEquals;
	public $Enderecocliente_IsLike;
	public $Enderecocliente_IsNotLike;
	public $Enderecocliente_BeginsWith;
	public $Enderecocliente_EndsWith;
	public $Enderecocliente_GreaterThan;
	public $Enderecocliente_GreaterThanOrEqual;
	public $Enderecocliente_LessThan;
	public $Enderecocliente_LessThanOrEqual;
	public $Enderecocliente_In;
	public $Enderecocliente_IsNotEmpty;
	public $Enderecocliente_IsEmpty;
	public $Enderecocliente_BitwiseOr;
	public $Enderecocliente_BitwiseAnd;
	public $Bairrocliente_Equals;
	public $Bairrocliente_NotEquals;
	public $Bairrocliente_IsLike;
	public $Bairrocliente_IsNotLike;
	public $Bairrocliente_BeginsWith;
	public $Bairrocliente_EndsWith;
	public $Bairrocliente_GreaterThan;
	public $Bairrocliente_GreaterThanOrEqual;
	public $Bairrocliente_LessThan;
	public $Bairrocliente_LessThanOrEqual;
	public $Bairrocliente_In;
	public $Bairrocliente_IsNotEmpty;
	public $Bairrocliente_IsEmpty;
	public $Bairrocliente_BitwiseOr;
	public $Bairrocliente_BitwiseAnd;
	public $Estadocliente_Equals;
	public $Estadocliente_NotEquals;
	public $Estadocliente_IsLike;
	public $Estadocliente_IsNotLike;
	public $Estadocliente_BeginsWith;
	public $Estadocliente_EndsWith;
	public $Estadocliente_GreaterThan;
	public $Estadocliente_GreaterThanOrEqual;
	public $Estadocliente_LessThan;
	public $Estadocliente_LessThanOrEqual;
	public $Estadocliente_In;
	public $Estadocliente_IsNotEmpty;
	public $Estadocliente_IsEmpty;
	public $Estadocliente_BitwiseOr;
	public $Estadocliente_BitwiseAnd;
	public $Telefonecliente_Equals;
	public $Telefonecliente_NotEquals;
	public $Telefonecliente_IsLike;
	public $Telefonecliente_IsNotLike;
	public $Telefonecliente_BeginsWith;
	public $Telefonecliente_EndsWith;
	public $Telefonecliente_GreaterThan;
	public $Telefonecliente_GreaterThanOrEqual;
	public $Telefonecliente_LessThan;
	public $Telefonecliente_LessThanOrEqual;
	public $Telefonecliente_In;
	public $Telefonecliente_IsNotEmpty;
	public $Telefonecliente_IsEmpty;
	public $Telefonecliente_BitwiseOr;
	public $Telefonecliente_BitwiseAnd;
	public $Celularcliente_Equals;
	public $Celularcliente_NotEquals;
	public $Celularcliente_IsLike;
	public $Celularcliente_IsNotLike;
	public $Celularcliente_BeginsWith;
	public $Celularcliente_EndsWith;
	public $Celularcliente_GreaterThan;
	public $Celularcliente_GreaterThanOrEqual;
	public $Celularcliente_LessThan;
	public $Celularcliente_LessThanOrEqual;
	public $Celularcliente_In;
	public $Celularcliente_IsNotEmpty;
	public $Celularcliente_IsEmpty;
	public $Celularcliente_BitwiseOr;
	public $Celularcliente_BitwiseAnd;
	public $Emailcliente_Equals;
	public $Emailcliente_NotEquals;
	public $Emailcliente_IsLike;
	public $Emailcliente_IsNotLike;
	public $Emailcliente_BeginsWith;
	public $Emailcliente_EndsWith;
	public $Emailcliente_GreaterThan;
	public $Emailcliente_GreaterThanOrEqual;
	public $Emailcliente_LessThan;
	public $Emailcliente_LessThanOrEqual;
	public $Emailcliente_In;
	public $Emailcliente_IsNotEmpty;
	public $Emailcliente_IsEmpty;
	public $Emailcliente_BitwiseOr;
	public $Emailcliente_BitwiseAnd;
	public $Codigocliente_Equals;
	public $Codigocliente_NotEquals;
	public $Codigocliente_IsLike;
	public $Codigocliente_IsNotLike;
	public $Codigocliente_BeginsWith;
	public $Codigocliente_EndsWith;
	public $Codigocliente_GreaterThan;
	public $Codigocliente_GreaterThanOrEqual;
	public $Codigocliente_LessThan;
	public $Codigocliente_LessThanOrEqual;
	public $Codigocliente_In;
	public $Codigocliente_IsNotEmpty;
	public $Codigocliente_IsEmpty;
	public $Codigocliente_BitwiseOr;
	public $Codigocliente_BitwiseAnd;

}

?>