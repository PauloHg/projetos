<?php
/** @package    PhreezeLoja::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * ProdutoCriteria allows custom querying for the Produto object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package PhreezeLoja::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ProdutoCriteriaDAO extends Criteria
{

	public $Codproduto_Equals;
	public $Codproduto_NotEquals;
	public $Codproduto_IsLike;
	public $Codproduto_IsNotLike;
	public $Codproduto_BeginsWith;
	public $Codproduto_EndsWith;
	public $Codproduto_GreaterThan;
	public $Codproduto_GreaterThanOrEqual;
	public $Codproduto_LessThan;
	public $Codproduto_LessThanOrEqual;
	public $Codproduto_In;
	public $Codproduto_IsNotEmpty;
	public $Codproduto_IsEmpty;
	public $Codproduto_BitwiseOr;
	public $Codproduto_BitwiseAnd;
	public $Nomeproduto_Equals;
	public $Nomeproduto_NotEquals;
	public $Nomeproduto_IsLike;
	public $Nomeproduto_IsNotLike;
	public $Nomeproduto_BeginsWith;
	public $Nomeproduto_EndsWith;
	public $Nomeproduto_GreaterThan;
	public $Nomeproduto_GreaterThanOrEqual;
	public $Nomeproduto_LessThan;
	public $Nomeproduto_LessThanOrEqual;
	public $Nomeproduto_In;
	public $Nomeproduto_IsNotEmpty;
	public $Nomeproduto_IsEmpty;
	public $Nomeproduto_BitwiseOr;
	public $Nomeproduto_BitwiseAnd;
	public $Tipoproduto_Equals;
	public $Tipoproduto_NotEquals;
	public $Tipoproduto_IsLike;
	public $Tipoproduto_IsNotLike;
	public $Tipoproduto_BeginsWith;
	public $Tipoproduto_EndsWith;
	public $Tipoproduto_GreaterThan;
	public $Tipoproduto_GreaterThanOrEqual;
	public $Tipoproduto_LessThan;
	public $Tipoproduto_LessThanOrEqual;
	public $Tipoproduto_In;
	public $Tipoproduto_IsNotEmpty;
	public $Tipoproduto_IsEmpty;
	public $Tipoproduto_BitwiseOr;
	public $Tipoproduto_BitwiseAnd;
	public $Qtdeproduto_Equals;
	public $Qtdeproduto_NotEquals;
	public $Qtdeproduto_IsLike;
	public $Qtdeproduto_IsNotLike;
	public $Qtdeproduto_BeginsWith;
	public $Qtdeproduto_EndsWith;
	public $Qtdeproduto_GreaterThan;
	public $Qtdeproduto_GreaterThanOrEqual;
	public $Qtdeproduto_LessThan;
	public $Qtdeproduto_LessThanOrEqual;
	public $Qtdeproduto_In;
	public $Qtdeproduto_IsNotEmpty;
	public $Qtdeproduto_IsEmpty;
	public $Qtdeproduto_BitwiseOr;
	public $Qtdeproduto_BitwiseAnd;
	public $Valordeproduto_Equals;
	public $Valordeproduto_NotEquals;
	public $Valordeproduto_IsLike;
	public $Valordeproduto_IsNotLike;
	public $Valordeproduto_BeginsWith;
	public $Valordeproduto_EndsWith;
	public $Valordeproduto_GreaterThan;
	public $Valordeproduto_GreaterThanOrEqual;
	public $Valordeproduto_LessThan;
	public $Valordeproduto_LessThanOrEqual;
	public $Valordeproduto_In;
	public $Valordeproduto_IsNotEmpty;
	public $Valordeproduto_IsEmpty;
	public $Valordeproduto_BitwiseOr;
	public $Valordeproduto_BitwiseAnd;

}

?>