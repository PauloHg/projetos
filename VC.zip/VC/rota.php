<html>
	<head>
		<title></title>
		<meta charset="utf-8">
		<script src="http://code.jquery.com/jquery-1.12.0.js"></script>
	</head>
	<body>
		<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<script type="text/javascript">
			function CalculaDistancia(){
				$('litResultado').html('Aguarde...');
				//Calcula a distância da viagem e as horas utilizando
				//múltiplas origens e destinos utilizando modo viagem
				var service= new google.maps.DistanceMatrixService();
				//agora vai executar o DistanceMatrixService
				service.getDistanceMatrix(
				{
					//Origem
					origins: [$("#txtOrigem").val()],
					//Destino
					destinations: [$("#txtDestino").val()],
					//Modo Viagem
					travelMode: google.maps.TravelMode.DRIVING,
					//Sistema de medida
					unitSystem: google.maps.unitSystem.Metric
					//Vai retornar o resultado da função callback

				}, callback);
			    }
				function callback(response, status){ 
					//Verifica se o destino existe mesmo
					if (status= != google.maps.DistanceMatrixStatus.OK)
						$('#litResultado').html(status);
					else{
						//Se o status for Ok
						//Endereço de origem = response.originAddress
						//Endereço de destino = response.destinationAddress
						//Distancia = response.rows[0].elements.distance.text
						//Duração = response.rows[0].elements[0].duration.text
						$('#litResultado').html("<strong>Origem:</strong>" 
							+ response.originAddress 
							+ "<br><strong>Destino:</strong>"
							+ response.destinationAddress
							+ "<strong>Distância:</strong>"
							+ response.rows[0].elements[0].distance.text 
							+ "<strong>Duração:</strong>"
							+ response.rows[0].elements[0].duration.text);
						//Atualizar o mapa
						$("#map").attr("src", "https://maps.google.com/maps?sadd="
							+ response.originAddress + "&daddr="
							+ response.destinationAddress + "&daddr="
							+ response.destinationAddress + "&output=embed");		
					}
				}
			}
		</script>
		<label for="txtOrigem"><strong>Endereço de Origem</strong></label>
		<input type="text" id="txtOrigem">
		<label for="txtDestino"><strong>Endereço de Destino</strong></label>
		<input type="text" id="txtDestino">

		<input type="button" value="Calcular distancia" onclick="CalculoDistancia()">

		<div><span id="litResultado"></span></div>

		<iframe width="750" scrolling="no" height="350"
		frameborder="0" id="map" marginheight="0" marginwidth="0"
		src="https://maps.google.com/maps?saddr=brasil&output=embed">
		</iframe>
	</body>
</html>